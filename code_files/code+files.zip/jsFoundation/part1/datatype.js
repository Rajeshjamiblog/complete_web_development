console.log("hello");
// console.log("chai");
/*

String
Number
Boolean
Bigint

Undefined
null

Object

Symbol

*/

// var score = 102

let score = 102;
let name = "chaicode.com";
let isLoggedin = false;

//object
let teaTypes = ["lemon tea", "orange tea", "oolong tea"];
let user = { firstname: "hitesh", lastname: "choudhary" };

let getScore = score;

console.log(getScore);
