let score = ((2 * (3 + 2)) - 1);
console.log(score);
