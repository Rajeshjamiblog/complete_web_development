const mathOperations = require("./mathOperationsC.js");

console.log(mathOperations.add(2, 2));
